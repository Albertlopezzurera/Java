package pt1.canal.tv;

import java.util.Date;

public class Pelicula extends Programa {

	public static String PREFIX = "PE";
	public static int MIN_ANY = 1900;
	public static int MAX_REPARTIMENT = 5;
	private String genere;
	private String director;
	private int any;
	private String[] repartiment;

	public Pelicula(String codi, Double preu, String titol, Integer durada, Date inici, String genere, String director,
			Integer any) {
		super(codi, preu, titol, durada, inici);
		this.genere = genere;
		this.director = director;
		this.any = any;
		this.repartiment = new String[0];
	}

	public Pelicula(String codi, Double preu, String titol, Integer durada, Date inici, String genere, String director,
			Integer any, String[] repartiment) {
		super(codi, preu, titol, durada, inici);
		this.genere = genere;
		this.director = director;
		this.any = any;
		if (repartiment == null) {
			this.repartiment = new String[0];
		} else if (repartiment != null) {
			this.repartiment = repartiment;
		}

	}

	public void addRepartiment(String actor) {
		if (repartiment.length < MAX_REPARTIMENT) {
			repartiment[repartiment.length] = actor;
		}
	}

	public void removeRepartiment(String actor) {
		if (repartiment.length > 1) {
			for (int i = 0; i < repartiment.length; i++) {
				if (repartiment[i].equals(actor)) {
					repartiment[i] = null;
					// borrar un hueco
				}
			}
		}
	}

	@Override
	public boolean cerca(String text) {
		if (super.titol.equalsIgnoreCase(text) && director.equalsIgnoreCase(text) && genere.equalsIgnoreCase(text)
				|| repartiment.toString().equalsIgnoreCase(text)) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public boolean cerca(Date hora) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getInfo1() {
		String nom = super.titol;
		return nom;
	}

	@Override
	public String getInfo2() {
		String tipus = genere;
		return tipus;
	}

	@Override
	public String[] getInfoExtra() {
		int top = 0;
		String[] llistainfo3 = new String[repartiment.length + 3];
		String direct = director;
		int year = any;
		llistainfo3[top] = "Director: " + direct;
		top++;
		llistainfo3[top] = "Any: " + year;
		top++;
		llistainfo3[top] = "Actors: ";
		top++;
		for (int i = 0; i < repartiment.length; i++) {
			llistainfo3[top] = repartiment[i].toString();
			top++;
		}
		return llistainfo3;
	}

	public static boolean validado(String codi, Double preu, String titol, Integer durada, Date inici, String genere,
			String director, Integer any, String[] repartiment) {
		if (preu >= 0 && titol != null && durada > 0 && codi.length() == 5 && codi.startsWith("PE") && inici != null
				&& any > MIN_ANY && repartiment != null) {
			return true;
		} else {
			return false;
		}
	}

	public String getGenere() {
		return genere;
	}

	public void setGenere(String genere) {
		this.genere = genere;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public int getAny() {
		return any;
	}

	public void setAny(int any) {
		this.any = any;
	}

	public String[] getRepartiment() {
		return repartiment;
	}

	public void setRepartiment(String[] repartiment) {
		this.repartiment = repartiment;
	}

}
