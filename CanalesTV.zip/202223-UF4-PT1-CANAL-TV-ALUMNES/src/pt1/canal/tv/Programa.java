package pt1.canal.tv;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public abstract class Programa implements Cercador {

	protected String codi;
	protected Double preu;
	protected String titol;
	protected Integer durada;
	protected Date inici;
	public static final int COL1 = 5 + 4;
	public static final int GAP1 = 2 + 4;
	public static final int COL2 = 20 + 4;
	public static final int GAP2 = 2 + 4;
	public static final int COL3 = 5 + 4;

	public Programa(String codi, Double preu, String titol, Integer durada, Date inici) {
		super();
		this.codi = codi;
		this.preu = preu;
		this.titol = titol;
		this.durada = durada;
		this.inici = inici;
	}

	@Override
	public boolean cerca(String text) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean cerca(Date hora) {
		if (hora == this.inici) {
			return true;
		} else {
			return false;
		}
	}

	public abstract String getInfo1();

	public abstract String getInfo2();

	public abstract String[] getInfoExtra();

	public String mostrarPrograma() {

		// para enseñar solo la hora hay que cambiar el formato
		SimpleDateFormat hora = new SimpleDateFormat("HH:mm");

		// PRIMERA LINIA
		String resultado = "\n";
		resultado += StringUtils.center(hora.format(getInici()), COL1);
		resultado += StringUtils.center("", GAP1);
		resultado += StringUtils.rightPad(getCodi() + " " + getInfo1(), COL2);
		resultado += StringUtils.center("", GAP2);
		resultado += StringUtils.center("" + getDurada() + " min.", COL3);
		resultado += "\n";
		// SEGUNDA LINIA
		resultado += StringUtils.repeat(" ", COL1);
		resultado += StringUtils.center("", GAP1);
		// abreviar un texto
		String info2 = StringUtils.abbreviate(getInfo2(), COL2);
		resultado += StringUtils.rightPad(info2, COL2);
		resultado += StringUtils.center("", GAP2);
		resultado += StringUtils.center(getPreu() + "€", COL3);
		resultado += "\n";
		// TERCERA LINIA
		for (String extra : getInfoExtra()) {
			resultado += StringUtils.repeat(" ", COL1);
			resultado += StringUtils.center(" ", GAP1);
			resultado += StringUtils.rightPad(extra, COL2);
			resultado += StringUtils.repeat(" ", GAP2);
			resultado += StringUtils.repeat(" ", COL3);
			resultado += "\n";
		}

		/*
		 * // va StrinUtils, rightPad o leftPad StringUtils.leftPad("texto", COL1, "*");
		 * StringUtils.repeat("t", GAP1); StringUtils.rightPad("durada", COL2, "$");
		 * StringUtils.leftPad("", GAP2, "@"); System.out.println("\n");
		 * 
		 * StringUtils.leftPad("", COL1); StringUtils.repeat("", GAP1);
		 * StringUtils.center(getInfo1(), COL2); StringUtils.leftPad("", GAP2, "");
		 * System.out.println("\n");
		 */
		return resultado;
	}

	public static boolean validado(String codi, Double preu, String titol, Integer durada, Date inici) {
		if (preu > 0 && titol != null && durada > 0 && codi.length() == 5 && inici != null) {
			return true;
		} else {
			return false;
		}
	}

	public static int getAmpleInforme() {
		return 0;
	}

	public String getCodi() {
		return codi;
	}

	public void setCodi(String codi) {
		this.codi = codi;
	}

	public Double getPreu() {
		return preu;
	}

	public void setPreu(Double preu) {
		this.preu = preu;
	}

	public String getTitol() {
		return titol;
	}

	public void setTitol(String titol) {
		this.titol = titol;
	}

	public Integer getDurada() {
		return durada;
	}

	public void setDurada(Integer durada) {
		this.durada = durada;
	}

	public Date getInici() {
		return inici;
	}

	public void setInici(Date inici) {
		this.inici = inici;
	}

}
