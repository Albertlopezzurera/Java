package pt1.canal.tv;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class CanalPagament {

	public static final int COL1 = 5 + 4;
	public static final int GAP1 = 2 + 4;
	public static final int COL2 = 20 + 5;
	public static final int GAP2 = 2 + 4;
	public static final int COL3 = 5 + 4;

	public static int MAX_PROGRAMES = 10;
	private Programa[] programacio = new Programa[MAX_PROGRAMES];
	public int top = 0;

	public CanalPagament() {
		super();
	}

	public Programa afegirPelicula(String codi, Double preu, String titol, Integer durada, Date inici, String genere,
			String director, Integer any, String[] repartiment) {
		for (int i = 0; i < top; i++) {
			if (codi.equals(programacio[i].codi) || inici.equals(programacio[i].inici)) {
				return null;
			}
		}
		Pelicula peli = new Pelicula(codi, preu, titol, durada, inici, genere, director, any, repartiment);
		boolean valida = Pelicula.validado(codi, preu, titol, durada, inici, genere, director, any,
				peli.getRepartiment());
		if (valida) {
			programacio[top] = peli;
		} else {
			return null;
		}
		top++;
		return programacio[top];
	}

	public Programa afegirSerie(String codi, Double preu, String titol, Integer durada, Date inici, String serie,
			Integer temporada, Integer capitol) {
		for (int i = 0; i < top; i++) {
			if (codi.equals(programacio[i].codi) || inici.equals(programacio[i].inici)) {
				return null;
			}
		}
		boolean valida = Capitol.validado(codi, preu, titol, durada, inici, serie, temporada, capitol);
		if (!valida || top > MAX_PROGRAMES) {
			return null;
		} else {
			programacio[top] = new Capitol(codi, preu, titol, durada, inici, serie, temporada, capitol);
		}
		top++;
		return programacio[top];
	}

	public Programa esborrarPrograma(String codi) {
		for (int i = 0; i < programacio.length; i++) {
			if (codi.equals(programacio[i])) {
				programacio[i] = null;
				return programacio[i];
			}
		}
		return null;
	}

	public String mostrarProgramacio(Date desde, Date fins, String text, Date hora) {
		String resultado = "\n";
		// PRIMERA LINIA
		resultado += StringUtils.repeat("#", COL1);
		resultado += StringUtils.repeat("#", GAP1);
		resultado += StringUtils.repeat("#", COL2);
		resultado += StringUtils.repeat("#", GAP2);
		resultado += StringUtils.repeat("#", COL3);
		resultado += "\n";

		// SEGUNDA LINIA
		resultado += StringUtils.rightPad("#", COL1);
		resultado += StringUtils.center(" ", GAP1);
		resultado += StringUtils.rightPad("PROGRAMACIO CANAL TV", COL2);
		resultado += StringUtils.center("", GAP2);
		resultado += StringUtils.leftPad("#", COL3);
		resultado += "\n";

		// TERCERA LINIA(DIA)
		String capça = capçaleraProgramacio(desde, fins, null);
		resultado += StringUtils.rightPad("# " + capça, COL1);
		resultado += StringUtils.center("", GAP1);
		resultado += StringUtils.rightPad(" #", GAP2);
		resultado += StringUtils.leftPad("", COL3);
		resultado += "\n";

		// CUARTA LINIA
		resultado += StringUtils.repeat("#", COL1);
		resultado += StringUtils.repeat("#", GAP1);
		resultado += StringUtils.repeat("#", COL2);
		resultado += StringUtils.repeat("#", GAP2);
		resultado += StringUtils.repeat("#", COL3);
		resultado += "\n";

		for (int i = 0; i < top; i++) {
			resultado += "  " + capçaleraData(programacio[i].getInici());
			resultado += "\n";
			resultado += StringUtils.repeat("-", COL1);
			resultado += StringUtils.repeat("-", GAP1);
			resultado += StringUtils.repeat("-", COL2);
			resultado += StringUtils.repeat("-", GAP2);
			resultado += StringUtils.repeat("-", COL3);
			resultado += programacio[i].mostrarPrograma();
			resultado += "\n";
		}
		return resultado;
	}

	private String capçaleraProgramacio(Date desde, Date fins, Integer total) {
		Integer resultado = 0;
		for (int i = 0; i < top; i++) {
			if (programacio[i].getInici() == desde) {
				resultado = resultado + 1;
			}
		}
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String data = "des de " + sdf.format(desde) + " fins " + sdf.format(fins) + " " + resultado + " programes";
		return data;
	}

	private String capçaleraData(Date data) {
		SimpleDateFormat sdf = new SimpleDateFormat("EEEEE, MMMM yyyy");
		return sdf.format(data);
	}

	private void ordenarProgramacio() {
		Arrays.sort(programacio, new Comparator<Programa>() {
			@Override
			public int compare(Programa o1, Programa o2) {
				if (o1 == null && o2 == null) {
					return 0;
				}
				if (o1 == null) {
					return 1;
				}
				if (o2 == null) {
					return -1;
				}
				if (o1.getInici().before(o2.getInici())) {
					return -1;
				}
				if (o2.getInici().before(o1.getInici())) {
					return 1;
				}
				return 0;
			}
		});
	}

	public Programa[] getProgramacio() {
		return programacio;
	}

	public void setProgramacio(Programa[] programacio) {
		this.programacio = programacio;
	}

}
