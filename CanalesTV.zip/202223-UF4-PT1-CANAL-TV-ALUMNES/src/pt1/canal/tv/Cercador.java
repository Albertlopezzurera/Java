package pt1.canal.tv;

import java.util.Date;

public interface Cercador {

	public boolean cerca(String text);

	public boolean cerca(Date hora);
}
