package pt1.canal.tv;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class MainUF4Pt1 {

	public static void main(String[] args) throws ParseException {
		CanalPagament cp = new CanalPagament();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm");

		cp.afegirPelicula("PR100", 1.05, "Pink Flamingos", 93, sdf.parse("2018/11/06 03:55"), "Comèdia", "John Waters",
				1972, null);
		cp.afegirPelicula("PE101", 2.15, "Polyester", 86, sdf.parse("2018/11/06 02:15"), "Comèdia Negra", "John Waters",
				1901, new String[] { "Albert Lopez", "Lionel Messi" });
		cp.afegirPelicula("PR102", 0.00, "Cry-Baby", 85, sdf.parse("2018/11/05 21:35"), "Comèdia Romàntica",
				"John Waters", 1990, new String[] { "Johnny Depp", "Amy Locane", "Iggy Pop", "Traci Lords" });
		cp.afegirPelicula("PR103", 2.45, "Serial Mom", 93, sdf.parse("2018/11/06 00:15"), "Comèdia Negra - Thriller",
				"John Waters", 1981, null);

		cp.afegirSerie("SR218", 0.95, "After many suspicions and one witness statement", 58,
				sdf.parse("2018/11/04 23:15"), "Bron/Broen", 1, 8);
		cp.afegirSerie("SR217", 0.95, "The murderer's fifth and final truth", 58, sdf.parse("2018/11/04 22:05"),
				"Bron/Broen", 1, 7);
		cp.afegirSerie("SR521", 1.95, "Ten days after lawyer Anne Dragsholm was found dead", 60,
				sdf.parse("2018/11/05 23:15"), "Forbrydelsen", 2, 1);

		System.out.println(
				cp.mostrarProgramacio(sdf.parse("2016/11/01 00:00"), sdf.parse("2020/11/10 00:00"), null, null));

		// System.out.println(cp.mostrarProgramacio(sdf.parse("2018/11/05 23:15"),
		// sdf.parse("2018/11/05 00:00"),
		// "Ten days after lawyer Anne Dragsholm was found dead", null));

		/*
		 * #protected -private +public cursiva abstrat subrayado static
		 */
	}

}
