package pt1.canal.tv;

import java.util.Date;

public class Capitol extends Programa {

	public static String PREFIX = "SR";
	private String serie;
	private int temporada;
	private int capitol;

	public Capitol(String codi, Double preu, String titol, Integer durada, Date inici, String serie, Integer temporada,
			Integer capitol) {
		super(codi, preu, titol, durada, inici);
		this.codi = codi;
		this.preu = preu;
		this.titol = titol;
		this.durada = durada;
		this.inici = inici;
		this.serie = serie;
		this.temporada = temporada;
		this.capitol = capitol;
	}

	@Override
	public boolean cerca(String text) {
		if (this.serie.equalsIgnoreCase(text)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean cerca(Date hora) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getInfo1() {
		String codinom = serie;
		return codinom;
	}

	@Override
	public String getInfo2() {
		String cap = titol;
		return cap;
	}

	@Override
	public String[] getInfoExtra() {
		String[] tempcap = new String[1];
		tempcap[0] = "TEMP. " + temporada + "CAP. " + capitol;
		return tempcap;
	}

	public static boolean validado(String codi, Double preu, String titol, Integer durada, Date inici, String serie,
			Integer temporada, Integer capitol) {
		if (preu > 0 && titol != null && durada > 0 && codi.length() == 5 && codi.startsWith("SR") && inici != null
				&& temporada > 0 && capitol > 0) {
			return true;
		} else {
			return false;
		}
	}

	public String getSerie() {
		return serie;
	}

	public void setSerie(String serie) {
		this.serie = serie;
	}

	public int getTemporada() {
		return temporada;
	}

	public void setTemporada(int temporada) {
		this.temporada = temporada;
	}

	public int getCapitol() {
		return capitol;
	}

	public void setCapitol(int capitol) {
		this.capitol = capitol;
	}

}
