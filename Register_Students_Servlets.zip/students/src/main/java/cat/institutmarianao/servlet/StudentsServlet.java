package cat.institutmarianao.servlet;

import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cat.institutmarianao.domain.Student;
import cat.institutmarianao.repository.Repository;
import cat.institutmarianao.repository.impl.RepositoryImpl;

/**
 * Servlet implementation class StudentsServlet
 */
@WebServlet("/StudentsServlet")
public class StudentsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB
	public Repository repository;
       
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		//prepararem les dades que necessitem per a la vista students.jsp
		//agafar els cicles
		List<String> cycles = repository.getCycles();
		//agafar els estudiants 
		List<Student> students = repository.getStudents();
		//afegir com a atributs a la petició (atributs cycles, students)
		request.setAttribute("cycles", cycles);
		request.setAttribute("students", students);
		//forward a la vista students.jsp.
        request.getRequestDispatcher("/students.jsp").forward(request, response);
	}
}
