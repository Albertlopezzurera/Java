package cat.institutmarianao.servlet;

import java.io.IOException; 

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cat.institutmarianao.domain.Student;
import cat.institutmarianao.repository.Repository;

/**
 * Servlet implementation class RemoveServlet
 */
@WebServlet("/RemoveServlet")
public class RemoveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB
	public Repository repository;
       
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String dni = request.getParameter("dni");
		//eliminar dni
		Student deleteStudent = new Student();
		deleteStudent.setDni(dni);
		repository.removeStudent(deleteStudent);
		//redirigir a StudentsServlet
		response.sendRedirect("StudentsServlet");
	}


}
