package cat.institutmarianao.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.commons.beanutils.BeanUtils;

import cat.institutmarianao.domain.Student;
import cat.institutmarianao.repository.Repository;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB
	public Repository repository;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Student newStudent = new Student();
		newStudent.setCycle(request.getParameter("cycle"));
		List<String> modules = repository.getModules(newStudent.getCycle());
		request.setAttribute("modules", modules);
		request.setAttribute("student", newStudent);
		request.getRequestDispatcher("/register.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		Boolean buttonController = reciveButton(req);
		if (!buttonController) {
			resp.sendRedirect("StudentsServlet");
		} else {
			Student newStudent = createNewStudent(req);
			if (!validationRequestParametres(req, resp, newStudent)) {
				List<String> modules = repository.getModules(newStudent.getCycle());
				req.setAttribute("modules", modules);

				// Almacenar la lista de módulos seleccionados en el request
				req.setAttribute("selectedModules", newStudent.getModules());
				req.setAttribute("student", newStudent);
				req.getRequestDispatcher("register.jsp").forward(req, resp);
			} else {
				repository.addStudent(newStudent);
				resp.sendRedirect("StudentsServlet");
			}

		}
	}

	private Student createNewStudent(HttpServletRequest req) {
		Student newStudent = new Student();
		Map<String, String[]> mapRequest = req.getParameterMap();
		try {
			BeanUtils.populate(newStudent, mapRequest);
			newStudent.setModules(req.getParameterValues("modules"));
			newStudent.setCycle(req.getParameter("cycle"));
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}
		return newStudent;
	}

	private Boolean reciveButton(HttpServletRequest req) {
		String buttonController = req.getParameter("button");
		if (buttonController.equals("Cancel")) {
			return false;
		} else {
			return true;
		}
	}

	private boolean validationRequestParametres(HttpServletRequest req, HttpServletResponse resp, Student newStudent) {
		// Crear un Validator para realizar la validación
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();

		// Realizar la validación
		Set<ConstraintViolation<Student>> violations = validator.validate(newStudent);

		if (violations.isEmpty()) {
			return true; // La validación es exitosa
		} else {
			// Si hay violaciones, procesar los mensajes de error y almacenarlos en req
			for (ConstraintViolation<Student> violation : violations) {
				String propertyName = violation.getPropertyPath().toString();
				String errorMessage = violation.getMessage();
				req.setAttribute(propertyName + "Error", errorMessage);
			}
			return false; // La validación falla
		}
	}

}
