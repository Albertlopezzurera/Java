package cat.institutmarianao.repository;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import cat.institutmarianao.domain.Student;

/**
 * Session Bean implementation class Repository
 */
@Local
public interface Repository {

	public List<String> getCycles();
	public List<String> getModules(String cycle);
	public List<Student> getStudents();
	public void addStudent(Student student);
	public void removeStudent(Student student);
}
